
function swap() {
document.getElementById("js").src = js1.jpg;
    alert('Wow, JavaScript is nifty!');
}

